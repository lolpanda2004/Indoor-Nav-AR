﻿using System;

namespace UnityEngine.XR.iOS
{
	public struct ARSize
	{
		public double width;
		public double height;
	}
}

