﻿using System;

namespace UnityEngine.XR.iOS
{
	public struct ARRect
	{
		public ARPoint origin;
		public ARSize  size;
	}
}

