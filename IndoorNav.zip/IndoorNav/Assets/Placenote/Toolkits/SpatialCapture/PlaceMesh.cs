﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


public class PlaceMesh : MonoBehaviour {

	public string APIKey;
	public string MapID;	
	public GameObject planePrefab;
	/*public GameObject fustrumPrefab;
	public Material denseCloudMt;*/

}
