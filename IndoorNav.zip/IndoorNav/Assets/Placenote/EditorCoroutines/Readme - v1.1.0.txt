EditorCoroutines by Marijn Zwemmer

Use Coroutines in the Editor like you're used to, examples are in CoroutineWindowExample.cs.